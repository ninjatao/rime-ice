local reduce_freq_words =
{ 	["示~例~"] = { "shili", },
	["颜射"] = { "yanshe", },
}
return reduce_freq_words